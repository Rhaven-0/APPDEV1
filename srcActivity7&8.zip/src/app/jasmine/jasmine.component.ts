import { Component } from '@angular/core';

@Component({
  selector: 'app-jasmine',
  standalone: true,
  templateUrl: './jasmine.component.html',
  styleUrl: './jasmine.component.css'
})
export class JasmineComponent {
  leader = "Jasmine";
  type = "Type: Steel";
  gymBadge = "Gym Badge: Mineral Badge";
  pokemons = "Pokemons: Magnemite, Magnemite, Steelix";
}
