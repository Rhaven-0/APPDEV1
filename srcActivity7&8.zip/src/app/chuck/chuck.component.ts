import { Component } from '@angular/core';
import { SidebarComponent } from '../sidebar/sidebar.component';

@Component({
  selector: 'app-chuck',
  standalone: true,
  templateUrl: './chuck.component.html',
  styleUrl: './chuck.component.css'
})
export class ChuckComponent {
  leader = "Chuck";
  type = "Type: Fighting";
  gymBadge = "Gym Badge: Storm Badge";
  pokemons = "Pokemons: Primeape, Poliwrath";
}
