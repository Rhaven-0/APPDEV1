import { Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { LegendaryPokemonService } from '../legendary-pokemon';

@Component({
  selector: 'app-pokemon-list',
  standalone: true,
  imports: [],
  templateUrl: './pokemon-list.html',
  styleUrl: './pokemon-list.css',
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class PokemonListComponent {
  kantoLegendaries: { name: string; type: string }[] = [];
  johtoLegendaries: { name: string; type: string }[] = [];

  // Inject the service into the component
  constructor(private pokemonService: LegendaryPokemonService) {}

  // On the initialization of the component, load the data
  ngOnInit(): void {
    this.kantoLegendaries = this.pokemonService.getKantoLegendaries();
    this.johtoLegendaries = this.pokemonService.getJohtoLegendaries();
  }
}