import { Component } from '@angular/core';

@Component({
  selector: 'app-clair',
  standalone: true,
  templateUrl: './clair.component.html',
  styleUrl: './clair.component.css'
})
export class ClairComponent {
  leader = "Clair";
  type = "Type: Dragon";
  gymBadge = "Gym Badge: Rising Badge";
  pokemons = "Pokemons: Dragonair. Dragonair, Gyarados, Kingdra";
}
