import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Falkner } from './Falkner/Falkner';
import { Bugsy } from './bugsy/bugsy';
import { Whitney } from './whitney/whitney';
import { Morty } from './Morty/Morty';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { ChuckComponent } from './chuck/chuck.component';
import { JasmineComponent } from './jasmine/jasmine.component';
import { PryceComponent } from './pryce/pryce.component';
import { ClairComponent } from './clair/clair.component';
import { LegendaryPokemonService} from './legendary-pokemon';
import { PokemonListComponent } from './pokemon-list/pokemon-list'; 

const routes: Routes = [
  {
    path: 'Falkner', component: Falkner,
  },
  {
    path: 'specifications', component: Bugsy,
  },
  {
    path: 'key-features', component: Whitney,
  },
  {
    path: 'instructions', component: Morty,
  },
  {
    path: 'chuck', component: ChuckComponent,
  },
  {
    path: 'jasmine', component: JasmineComponent,
  },
  {
    path: 'pryce', component: PryceComponent,
  },
  {
    path: 'clair', component: ClairComponent,
  },
  {
    path: 'landingPage', component: LandingPageComponent,
  },
  {
    path: 'legendary Pokemon', component: LegendaryPokemonService,
  }
  {
    path: 'Pokemon List', component: PokemonListComponent,
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

