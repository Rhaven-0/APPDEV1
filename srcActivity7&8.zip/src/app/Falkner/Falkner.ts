import { Component } from '@angular/core';

@Component({
  selector: 'app-product-overview',
  standalone: true,
  templateUrl: './product-overview.component.html',
  styleUrl: './product-overview.component.css'
})
export class Falkner {
  leader = "Falkner";
  type = "Type: Flying";
  gymBadge = "Gym Badge: Zephyr Badge";
  pokemons = "Pokemons: Pidgey, Pidgeotto";
}

