import { Component } from '@angular/core';

@Component({
  selector: 'app-key-features',
  standalone: true,
  templateUrl: './key-features.component.html',
  styleUrl: './key-features.component.css'
})
export class Whitney {
  leader = "Whitney";
  type = "Type: Normal";
  gymBadge = "Gym Badge: Plain Badge";
  pokemons = "Pokemons: Clefairy, Miltank";
}
