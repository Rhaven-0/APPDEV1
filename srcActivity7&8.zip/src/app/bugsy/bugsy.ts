import { Component } from '@angular/core';

@Component({
  selector: 'app-product-specifications',
  standalone: true,
  templateUrl: './product-specifications.component.html',
  styleUrl: './product-specifications.component.css'
})
export class Bugsy {
  leader = "Bugsy";
  type = "Type: Bug";
  gymBadge = "Gym Badge: Hive Badge";
  pokemons = "Pokemons: Metapod, Kakuna, Scyther";
}
