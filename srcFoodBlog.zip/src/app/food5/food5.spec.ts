import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Food5 } from './food5';

describe('Food5', () => {
  let component: Food5;
  let fixture: ComponentFixture<Food5>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Food5]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Food5);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
