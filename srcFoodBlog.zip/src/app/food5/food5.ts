import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
@Component({
selector: 'app-food5',
standalone: true,
imports: [CommonModule],
templateUrl: './food5.html',
styleUrls: ['./food5.css'],
})
export class Food5 {
food: any;
constructor (private http: HttpClient){
this.http.get('https://www.themealdb.com/api/json/v1/1/search.php?s=Kentucky_Fried_Chicken').subscribe(
response => {
this.food = response;
},
error => {
console.error('Error:', error);
}
)
}

}
