import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Food10 } from './food10';

describe('Food10', () => {
  let component: Food10;
  let fixture: ComponentFixture<Food10>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Food10]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Food10);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
