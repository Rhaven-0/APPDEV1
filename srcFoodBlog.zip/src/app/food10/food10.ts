import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
@Component({
selector: 'app-food10',
standalone: true,
imports: [CommonModule],
templateUrl: './food10.html',
styleUrls: ['./food10.css'],
})
export class Food10 {
food: any;
constructor (private http: HttpClient){
this.http.get('https://www.themealdb.com/api/json/v1/1/search.php?s=Chicken_Karaage').subscribe(
response => {
this.food = response;
},
error => {
console.error('Error:', error);
}
)
}

}
