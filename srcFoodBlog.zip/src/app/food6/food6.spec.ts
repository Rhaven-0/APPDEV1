import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Food6 } from './food6';

describe('Food6', () => {
  let component: Food6;
  let fixture: ComponentFixture<Food6>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Food6]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Food6);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
