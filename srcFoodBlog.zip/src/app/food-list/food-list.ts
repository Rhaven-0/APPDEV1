import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
@Component({
selector: 'app-food-list',
standalone: true,
imports: [CommonModule],
templateUrl: './food-list.html',
styleUrls: ['./food-list.css'],
})
export class FoodList {
food: any;
constructor (private http: HttpClient){
this.http.get('https://www.themealdb.com/api/json/v1/1/search.php?s=Migas').subscribe(
response => {
this.food = response;
},
error => {
console.error('Error:', error);
}
)
}

}
