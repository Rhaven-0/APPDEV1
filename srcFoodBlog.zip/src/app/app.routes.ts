import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FoodList } from './food-list/food-list';
import { Food2 } from './food2/food2';
import { Food3 } from './food3/food3';
import { Food4 } from './food4/food4';
import { Food5 } from './food5/food5';
import { Food6 } from './food6/food6';
import { Food7 } from './food7/food7';
import { Food8 } from './food8/food8';
import { Food9 } from './food9/food9';
import { Food10 } from './food10/food10';

export const routes: Routes = [
  { path: '', redirectTo: 'food1', pathMatch: 'full' },
  { path: 'food1', component: FoodList },
  { path: 'food2', component: Food2 },
  { path: 'food3', component: Food3 },
  { path: 'food4', component: Food4 },
  { path: 'food5', component: Food5 },
  { path: 'food6', component: Food6 },
  { path: 'food7', component: Food7 },
  { path: 'food8', component: Food8 },
  { path: 'food9', component: Food9 },
  { path: 'food10', component: Food10 },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

