import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { RouterOutlet } from '@angular/router';  
import { CommonModule } from '@angular/common'; 
import { FoodList } from './food-list/food-list';
import { Food2 } from './food2/food2';
import { Food3 } from './food3/food3';
import { Food4 } from './food4/food4';
import { Food5 } from './food5/food5';
import { Food6 } from './food6/food6';
import { Food7 } from './food7/food7';
import { Food8 } from './food8/food8';
import { Food9 } from './food9/food9';
import { Food10 } from './food10/food10';
import { routes } from './app.routes';  

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,    
    RouterOutlet,    
    FoodList,        
    Food2,
    Food3,
    Food4,
    Food5,
    Food6,
    Food7,
    Food8,
    Food9,
    Food10
  ],
  templateUrl: './app.html',
  styleUrls: ['./app.css']
})
export class App {
  protected readonly title = 'my-food-blog'; 

  constructor(private router: Router) {}

  goToComponent(componentNumber: number) {
    this.router.navigate([`/food${componentNumber}`]);
  }
}
