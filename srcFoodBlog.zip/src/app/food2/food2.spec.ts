import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Food2 } from './food2';

describe('Food2', () => {
  let component: Food2;
  let fixture: ComponentFixture<Food2>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Food2]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Food2);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
