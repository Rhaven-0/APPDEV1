import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Food7 } from './food7';

describe('Food7', () => {
  let component: Food7;
  let fixture: ComponentFixture<Food7>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Food7]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Food7);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
