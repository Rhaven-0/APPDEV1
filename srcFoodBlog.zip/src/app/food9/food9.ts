import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
@Component({
selector: 'app-food9',
standalone: true,
imports: [CommonModule],
templateUrl: './food9.html',
styleUrls: ['./food9.css'],
})
export class Food9 {
food: any;
constructor (private http: HttpClient){
this.http.get('https://www.themealdb.com/api/json/v1/1/search.php?s=Fettuccine_Alfredo').subscribe(
response => {
this.food = response;
},
error => {
console.error('Error:', error);
}
)
}

}


