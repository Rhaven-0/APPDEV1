import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Food9 } from './food9';

describe('Food9', () => {
  let component: Food9;
  let fixture: ComponentFixture<Food9>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Food9]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Food9);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
