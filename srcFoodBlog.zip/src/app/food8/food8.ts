import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
@Component({
selector: 'app-food8',
standalone: true,
imports: [CommonModule],
templateUrl: './food8.html',
styleUrls: ['./food8.css'],
})
export class Food8 {
food: any;
constructor (private http: HttpClient){
this.http.get('https://www.themealdb.com/api/json/v1/1/search.php?s=Beef_Brisket_Pot_Roast').subscribe(
response => {
this.food = response;
},
error => {
console.error('Error:', error);
}
)
}

}


