import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Food8 } from './food8';

describe('Food8', () => {
  let component: Food8;
  let fixture: ComponentFixture<Food8>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Food8]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Food8);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
