import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Food4 } from './food4';

describe('Food4', () => {
  let component: Food4;
  let fixture: ComponentFixture<Food4>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Food4]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Food4);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
