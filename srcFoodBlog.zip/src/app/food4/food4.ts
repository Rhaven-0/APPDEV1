import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
@Component({
selector: 'app-food4',
standalone: true,
imports: [CommonModule],
templateUrl: './food4.html',
styleUrls: ['./food4.css'],
})
export class Food4 {
food: any;
constructor (private http: HttpClient){
this.http.get('https://www.themealdb.com/api/json/v1/1/search.php?s=Tortang_Talong').subscribe(
response => {
this.food = response;
},
error => {
console.error('Error:', error);
}
)
}

}


