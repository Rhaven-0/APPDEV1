import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { forkJoin, of } from 'rxjs';
import { map } from 'rxjs/operators';

interface CarModel {
  Model_Name: string;
  imageUrl?: string;
}

@Component({
  selector: 'app-carlist',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './carlist.html',
  styleUrls: ['./carlist.css']
})
export class carlist implements OnInit {
  carMakers: any[] = [];  
  carModels: CarModel[] = [];  
  selectedMaker: string = '';
  selectedMakerName: string = '';
  isLoadingModels: boolean = false;

  private carImages: { [key: string]: string } = {
    // Toyota (3 models)
    'CAMRY': 'camry.png',
    'SUPRA': 'Supra.png',
    'FORTUNER': 'fortuner.png',
    
    // Honda (3 models)
    'CIVIC': 'civictyper.png',
    'CITY': 'city.jpeg',
    'BRIO': 'brio.png',
    
    // Ford (3 models)
    'RAPTOR': 'raptor.png',
    'MUSTANG': 'mustang.png',
    'TERRITORY': 'territory.png',
    
    // Tesla (3 models)
    'CYBERTRUCK': 'cybertruck.png',
    'MODEL S': 'models.png',
    'MODEL Y': 'modely.png',
    
    // BMW (3 models)
    'BMW M2 COUPE': 'm2coupe.png',
    'BMW Z4 ROADSTER': 'z4roadster.png',
    'BMW I7': 'i7.png',
    
    // Mercedes-Benz (3 models)
    'G-CLASS': 'g-class.png',
    'MAYBACH S-CLASS': 'maybachs-class.png',
    'S-CLASS': 's-class.png',
    
    // Chevrolet (3 models)
    'CORVETTE': 'corvette.png',
    'TAHOE': 'tahoe.png',
    'TRAILBLAZER': 'trailblazer.png',
    
    // Nissan (3 models)
    'TERRA': 'terra.png',
    'LEAF': 'leaf.png',
    'Gt-R': 'gtr.png',
    
    // Audi (3 models)
    'R8': 'r8.png',
    'Q8': 'q8.png',
    'E-TRON GT': 'etrongt.png',
    
    // Porsche (3 models)
    '911 TURBO S  ': '911turbos.png',
    'CAYENNE': 'cayenne.png',
    'MACAN': 'macan.png',
    
    // Lamborghini
    // Rolls royce
    // Hyundai
    // Mazda
    // Maserrati
    // Mitsubishi
    // Barusu
    // Add more brands as you download images...
  };

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.loadCarMakers();
  }

  loadCarMakers() {
    const popularMakers = [
      'TOYOTA', 'HONDA', 'FORD', 'CHEVROLET', 'NISSAN', 
      'BMW', 'MERCEDES-BENZ', 'AUDI', 'VOLKSWAGEN', 'HYUNDAI',
      'KIA', 'MAZDA', 'SUBARU', 'JEEP', 'RAM', 'GMC',
      'LEXUS', 'TESLA', 'PORSCHE', 'LAND ROVER',
      'JAGUAR', 'MINI', 'ACURA', 'INFINITI', 'CADILLAC',
      'LINCOLN', 'BUICK', 'DODGE', 'CHRYSLER', 'MITSUBISHI',
      'GENESIS', 'ALFA ROMEO', 'FIAT', 'MASERATI', 'FERRARI',
      'LAMBORGHINI', 'BENTLEY', 'ROLLS-ROYCE', 'ASTON MARTIN', 'MCLAREN'
    ];

    this.http
      .get<any>('https://vpic.nhtsa.dot.gov/api/vehicles/getallmanufacturers?format=json')
      .subscribe((data) => {
        const uniqueMakers = new Map<string, any>();
        
        data.Results
          .filter((m: any) => {
            if (!m.Mfr_Name || !m.Mfr_ID) return false;
            const makerUpper = m.Mfr_Name.toUpperCase();
            return popularMakers.some(popular => makerUpper.includes(popular));
          })
          .forEach((m: any) => {
            const makerUpper = m.Mfr_Name.toUpperCase();
            const baseName = popularMakers.find(popular => makerUpper.includes(popular));
            
            if (baseName && !uniqueMakers.has(baseName)) {
              uniqueMakers.set(baseName, { id: m.Mfr_ID, name: baseName });
            }
          });
        
        this.carMakers = Array.from(uniqueMakers.values())
          .sort((a: any, b: any) => a.name.localeCompare(b.name));
        
        console.log('Filtered makers:', this.carMakers.length);
      });
  }

  onMakerChange() {
    if (!this.selectedMaker) return;
    
    this.isLoadingModels = true;
    this.carModels = [];
    
    const maker = this.carMakers.find(m => m.id === this.selectedMaker);
    this.selectedMakerName = maker?.name || '';
    
    this.http
      .get<any>(`https://vpic.nhtsa.dot.gov/api/vehicles/getmodelsformakeid/${this.selectedMaker}?format=json`)
      .subscribe((data) => {
        // Get all models from API
        const allModels = data.Results;
        
        if (allModels.length === 0) {
          this.isLoadingModels = false;
          return;
        }
        
        // Filter to only show models that we have images for
        const modelsWithImages = allModels.filter((model: any) => {
          const modelKey = model.Model_Name.toUpperCase().trim();
          return this.carImages[modelKey] !== undefined;
        });
        
        // If we have models with images, use those. Otherwise show first 3 with placeholders
        const modelsToShow = modelsWithImages.length > 0 
          ? modelsWithImages.slice(0, 3)  // Show only 3 models with images
          : allModels.slice(0, 3);         // Fallback to first 3 with placeholders
        
        const imageRequests = modelsToShow.map((model: any) => 
          this.fetchCarImage(this.selectedMakerName, model.Model_Name)
        );
        
        forkJoin<string[]>(imageRequests).subscribe((images: string[]) => {
          this.carModels = modelsToShow.map((model: any, index: number) => ({
            Model_Name: model.Model_Name,
            imageUrl: images[index]
          }));
          this.isLoadingModels = false;
        });
      });
  }

  fetchCarImage(maker: string, model: string) {
    // Normalize the model name for lookup
    const modelKey = model.toUpperCase().trim();
    
    // Check if we have a local image
    if (this.carImages[modelKey]) {
      return of(this.carImages[modelKey]);
    }
    
    // Fallback to colored placeholder
    const colors = ['4A90E2', 'E74C3C', '2ECC71', 'F39C12', '9B59B6', '1ABC9C'];
    const colorIndex = maker.length % colors.length;
    const color = colors[colorIndex];
    
    return of(`https://placehold.co/400x300/${color}/FFFFFF?text=${encodeURIComponent(model)}`);
  }
}