import { Component } from '@angular/core';
import { gymLeaderService } from '../gym-leader';
@Component({
  selector: 'app-morty',
  imports: [],
  standalone: true,
  templateUrl: './morty.html',
  styleUrl: './morty.css'
})
export class Morty {
leader: any;
  pokemons: any[] = [];
  gymBadge = '';

  constructor(private gymLeaderService: gymLeaderService) {}

  ngOnInit() {
    this.leader = this.gymLeaderService.getLeaderByName('Morty');
    if (this.leader) {
      this.pokemons = this.leader.pokemons;
      this.gymBadge = this.leader.gymBadge;
    }
  }
}