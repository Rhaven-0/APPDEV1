import { Component } from '@angular/core';
import { gymLeaderService } from '../gym-leader';
@Component({
  selector: 'app-chuck',
  imports: [],
  templateUrl: './chuck.html',
  styleUrl: './chuck.css'
})
export class Chuck {
leader: any;
  pokemons: any[] = [];
  gymBadge = '';

  constructor(private gymLeaderService: gymLeaderService) {}

  ngOnInit() {
    this.leader = this.gymLeaderService.getLeaderByName('Chuck');
    if (this.leader) {
      this.pokemons = this.leader.pokemons;
      this.gymBadge = this.leader.gymBadge;
    }
  }
}
