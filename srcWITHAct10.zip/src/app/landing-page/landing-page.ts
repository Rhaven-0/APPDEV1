import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-landing-page',
  imports: [CommonModule],
  templateUrl: './landing-page.html',
  styleUrl: './landing-page.css'
})
export class LandingPage {
  lore = "The Johto region is a region of the Pokemon world. Johto is located west of Kanto, which together form a joint landmass that is south of Sinnoh and Sinjoh Ruins. The gym leaders that resides here that will test trainers are Falkner, Bugsy, Whitney, Chuck,Jasmine, Pryce, and Clair"
  gymLeaders = [
  { name: 'Falkner', image: 'Falkner.png' },
  { name: 'Bugsy', image: 'Bugsy.png' },
  { name: 'Whitney', image: 'Whitney.png' },
  { name: 'Morty', image: 'Morty.png' },
  { name: 'Chuck', image: 'Chuck.png' },
  { name: 'Jasmine', image: 'Jasmine.png' },
  { name: 'Pryce', image: 'Pryce.png' },
  { name: 'Clair', image: 'Clair.png' }
];
}
