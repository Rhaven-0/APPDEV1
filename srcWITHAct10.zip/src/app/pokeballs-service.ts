import { Injectable } from '@angular/core';
@Injectable({
providedIn: 'root'
})
export class PokeballsService {
getPokeballs() {
return [
    { name: 'Poke Ball', color: 'Red', image: 'Pokeball.png' },
    { name: 'Great Ball', color: 'Blue', image: 'GreatBall.png' },
    { name: 'Ultra Ball', color: 'Black', image: 'UltraBall.png' },
    { name: 'Master Ball', color: 'Purple', image: 'MasterBall.png' },
    { name: 'Premier Ball', color: 'White', image: 'PremierBall.png' },
    { name: 'Luxury Ball', color: 'Black', image: 'LuxuryBall.png' },
    { name: 'Quick Ball', color: 'Yellow', image: 'QuickBall.png' },
    { name: 'Net Ball', color: 'Cyan', image: 'NetBall.png' },
    { name: 'Dive Ball', color: 'Blue', image: 'DiveBall.png' },
    { name: 'Timer Ball', color: 'White', image: 'TimerBall.png' },
    ];
}
}
