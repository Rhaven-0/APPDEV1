import { Component } from '@angular/core';
import { gymLeaderService } from '../gym-leader';
@Component({
  selector: 'app-clair',
  imports: [],
  templateUrl: './clair.html',
  styleUrl: './clair.css'
})
export class Clair {
leader: any;
  pokemons: any[] = [];
  gymBadge = '';

  constructor(private gymLeaderService: gymLeaderService) {}

  ngOnInit() {
    this.leader = this.gymLeaderService.getLeaderByName('Clair');
    if (this.leader) {
      this.pokemons = this.leader.pokemons;
      this.gymBadge = this.leader.gymBadge;
    }
  }
}