import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrainerInformation } from './trainer-information';

describe('TrainerInformation', () => {
  let component: TrainerInformation;
  let fixture: ComponentFixture<TrainerInformation>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TrainerInformation]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TrainerInformation);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
