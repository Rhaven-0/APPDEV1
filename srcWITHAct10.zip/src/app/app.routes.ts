import { Routes } from '@angular/router';
import { Falkner } from './falkner/falkner';
import { Bugsy } from './bugsy/bugsy';
import { Whitney } from './whitney/whitney';
import { Morty } from './morty/morty';
import { Chuck } from './chuck/chuck';
import { Jasmine } from './jasmine/jasmine';
import { Pryce } from './pryce/pryce';
import { Clair } from './clair/clair';
import { LandingPage } from './landing-page/landing-page';
import { PokemonList } from './pokemon-list/pokemon-list';
import { TrainerForm } from './trainer-information/trainer-information';
import { Berries } from './berries/berries';
import { Pokeballs } from './pokeballs/pokeballs';

export const routes: Routes = [
    {
        path: 'falkner', component: Falkner
    },
    {
        path: 'bugsy', component: Bugsy
    },
    {
        path: 'whitney', component: Whitney
    },
    {
        path: 'morty', component: Morty
    },
    {
        path: 'chuck', component: Chuck
    },
    {
        path: 'jasmine', component: Jasmine
    },
    {
        path: 'pryce', component: Pryce
    },
    {
        path: 'clair', component: Clair
    },
    {
        path: '', component: LandingPage
    },
    {
        path: 'legendary-pokemons', component: PokemonList
    },
    {
        path: 'register-trainer', component: TrainerForm
    },
    {
        path: 'berries', component: Berries
    },
    {
        path: 'pokeballs', component: Pokeballs
    }
];
