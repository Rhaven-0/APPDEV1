import { Injectable } from '@angular/core';
@Injectable({
providedIn: 'root'
})
export class BerriesService {
getBerries() {
return[
    { name: 'Oran Berry', color: 'Blue', image: 'OranBerry.png' },
    { name: 'Sitrus Berry', color: 'Yellow', image: 'SitrusBerry.png' },
    { name: 'Cheri Berry', color: 'Bright Red', image: 'CheriBerry.png' },
    { name: 'Chesto Berry', color: 'Blue', image: 'ChestoBerry.png' },
    { name: 'Pecha Berry', color: 'Pink', image: 'PechaBerry.png' },
    { name: 'Rawst Berry', color: 'Green', image: 'RawstBerry.png' },
    { name: 'Aspear Berry', color: 'Yellow', image: 'AspearBerry.png' },
    { name: 'Leppa Berry', color: 'Orange-Red', image: 'LeppaBerry.png' },
    { name: 'Lum Berry', color: 'Green', image: 'LumBerry.png' },
    { name: 'Figy Berry', color: 'Red', image: 'FigyBerry.png' }
];
}
}
