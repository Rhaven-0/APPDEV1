import { Component } from '@angular/core';
import { gymLeaderService } from '../gym-leader';
@Component({
  selector: 'app-pryce',
  imports: [],
  templateUrl: './pryce.html',
  styleUrl: './pryce.css'
})
export class Pryce {
leader: any;
  pokemons: any[] = [];
  gymBadge = '';

  constructor(private gymLeaderService: gymLeaderService) {}

  ngOnInit() {
    this.leader = this.gymLeaderService.getLeaderByName('Pryce');
    if (this.leader) {
      this.pokemons = this.leader.pokemons;
      this.gymBadge = this.leader.gymBadge;
    }
  }
}
