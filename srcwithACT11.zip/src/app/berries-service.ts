import { Injectable } from '@angular/core';
@Injectable({
providedIn: 'root'
})
export class BerriesService {
getBerries() {
return[
    { name: 'Oran Berry', color: 'Blue', image: 'OranBerry.png', effects: 'Restores 10 HP' },
    { name: 'Sitrus Berry', color: 'Yellow', image: 'SitrusBerry.png', effects: 'Restores 25% HP when HP falls below 50%.' },
    { name: 'Cheri Berry', color: 'Bright Red', image: 'CheriBerry.png', effects: 'Cures paralysis.' },
    { name: 'Chesto Berry', color: 'Blue', image: 'ChestoBerry.png', effects: 'Cures sleep.' },
    { name: 'Pecha Berry', color: 'Pink', image: 'PechaBerry.png', effects: 'Cures poison.' },
    { name: 'Rawst Berry', color: 'Green', image: 'RawstBerry.png', effects: 'Cures burn.' },
    { name: 'Aspear Berry', color: 'Yellow', image: 'AspearBerry.png', effects: 'Cures freeze.' },
    { name: 'Leppa Berry', color: 'Orange-Red', image: 'LeppaBerry.png', effects: 'Restores 10 PP.' },
    { name: 'Lum Berry', color: 'Green', image: 'LumBerry.png', effects: 'Cures any non-volatile status condition and confusion.' },
    { name: 'Figy Berry', color: 'Red', image: 'FigyBerry.png', effects: 'Restores 33% HP when HP falls below 25%, but confuses Pokemon that hate spicy food. Restores 50% HP. Makes wild Pokemon that hate spicy flavors briefly pause.' }
];
}
}
