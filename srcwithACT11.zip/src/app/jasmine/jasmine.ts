import { Component } from '@angular/core';
import { gymLeaderService } from '../gym-leader';
@Component({
  selector: 'app-jasmine',
  imports: [],
  templateUrl: './jasmine.html',
  styleUrl: './jasmine.css'
})
export class Jasmine {
 leader: any;
  pokemons: any[] = [];
  gymBadge = '';

  constructor(private gymLeaderService: gymLeaderService) {}

  ngOnInit() {
    this.leader = this.gymLeaderService.getLeaderByName('Jasmine');
    if (this.leader) {
      this.pokemons = this.leader.pokemons;
      this.gymBadge = this.leader.gymBadge;
    }
  }
}
