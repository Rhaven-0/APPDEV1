import { TestBed } from '@angular/core/testing';

import { LengendaryPokemon } from './lengendary-pokemon';

describe('LengendaryPokemon', () => {
  let service: LengendaryPokemon;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LengendaryPokemon);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
