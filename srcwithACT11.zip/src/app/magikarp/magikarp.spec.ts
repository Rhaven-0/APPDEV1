import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Magikarp } from './magikarp';

describe('Magikarp', () => {
  let component: Magikarp;
  let fixture: ComponentFixture<Magikarp>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Magikarp]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Magikarp);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
