import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDividerModule } from '@angular/material/divider';
@Component({
  selector: 'app-magikarp',
  imports: [CommonModule, HttpClientModule, MatDividerModule],
  templateUrl: './magikarp.html',
  styleUrl: './magikarp.css'
})
export class Magikarp {
  pokemon: any = null;
  loading = true;
  error: string | null = null;

  constructor(private http: HttpClient) {
    this.loadPokemon();
  }

  loadPokemon() {
    this.loading = true;
    this.error = null;

    this.http.get('https://pokeapi.co/api/v2/pokemon/magikarp').subscribe({
      next: (res) => {
        this.pokemon = res;
        this.loading = false;
      },
      error: (err) => {
        console.error(err);
        this.error = 'Failed to load Pokémon';
        this.loading = false;
      }
    });
  }

  get displayName() {
    return this.pokemon?.name ? this.pokemon.name[0].toUpperCase() + this.pokemon.name.slice(1) : '';
  }
}
