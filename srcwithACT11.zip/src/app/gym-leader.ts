import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class gymLeaderService {
  getJohtoLeaders() {
    return [
      {
        name: 'Falkner',
        specialty: 'Flying',
        gymBadge: 'Zephyr Badge',
        img: 'Falkner.png',
        badgeImg: 'ZephyrBadge.png',
        pokemons: [
          { name: 'Pidgey', img: 'Pidgey.png' },
          { name: 'Pidgeotto', img: 'Pidgeotto.png' }
        ]
      },
      {
        name: 'Bugsy',
        specialty: 'Bug',
        gymBadge: 'HiveBadge',
        img: 'Bugsy.png',
        badgeImg: 'HiveBadge.png',
        pokemons: [
          { name: 'Metapod', img: 'Metapod.png' },
          { name: 'Kakuna', img: 'Kakuna.png' },
          { name: 'Scyther', img: 'Scyther.png' }
        ]
      },
      {
        name: 'Whitney',
        specialty: 'Normal',
        gymBadge: 'PlainBadge',
        img: 'Whitney.png',
        badgeImg: 'PlainBadge.png',
        pokemons: [
          { name: 'Clefairy', img: 'Clefairy.png' },
          { name: 'Miltank', img: 'Miltank.png' }
        ]
      },
      {
        name: 'Morty',
        specialty: 'Ghost',
        gymBadge: 'FogBadge',
        img: 'Morty.png',
        badgeImg: 'FogBadge.png',
        pokemons: [
          { name: 'Gastly', img: 'Gastly.png' },
          { name: 'Haunter', img: 'Haunter.png' },
          { name: 'Gengar', img: 'Gengar.png' }
        ]
      },
      {
        name: 'Chuck',
        specialty: 'Fighting',
        gymBadge: 'StormBadge',
        img: 'Chuck.png',
        badgeImg: 'StormBadge.png',
        pokemons: [
          { name: 'Primeape', img: 'Primeape.png' },
          { name: 'Poliwrath', img: 'Poliwrath.png' }
        ]
      },
      {
        name: 'Jasmine',
        specialty: 'Steel',
        gymBadge: 'MineralBadge',
        img: 'Jasmine.png',
        badgeImg: 'MineralBadge.png',
        pokemons: [
          { name: 'Magnemite', img: 'Magnemite.png' },
          { name: 'Steelix', img: 'Steelix.png' }
        ]
      },
      {
        name: 'Pryce',
        specialty: 'Ice',
        gymBadge: 'GlacierBadge',
        img: 'Pryce.png',
        badgeImg: 'GlacierBadge.png',
        pokemons: [
          { name: 'Seel', img: 'Seel.png' },
          { name: 'Dewgong', img: 'Dewgong.png' },
          { name: 'Piloswine', img: 'Piloswine.png' }
        ]
      },
      {
        name: 'Clair',
        specialty: 'Dragon',
        gymBadge: 'RisingBadge',
        img: 'Clair.png',
        badgeImg: 'RisingBadge.png',
        pokemons: [
          { name: 'Dragonair', img: 'Dragonair.png' },
          { name: 'Kingdra', img: 'Kingdra.png' }
        ]
      }
    ];
  }

  getLeaderByName(name: string) {
    return this.getJohtoLeaders().find(
      leader => leader.name.toLowerCase() === name.toLowerCase()
    );
  }
}
