import { Component } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { MatDividerModule } from '@angular/material/divider';

@Component({
  selector: 'app-mewtwo',
  standalone: true,
  imports: [CommonModule, HttpClientModule, MatDividerModule],
  templateUrl: './mewtwo.html',
  styleUrl: './mewtwo.css'
})
export class Mewtwo {
  pokemon: any = null;
  loading = true;
  error: string | null = null;

  constructor(private http: HttpClient) {
    this.loadPokemon();
  }

  loadPokemon() {
    this.loading = true;
    this.error = null;

    this.http.get('https://pokeapi.co/api/v2/pokemon/mewtwo').subscribe({
      next: (res) => {
        this.pokemon = res;
        this.loading = false;
      },
      error: (err) => {
        console.error(err);
        this.error = 'Failed to load Pokémon';
        this.loading = false;
      }
    });
  }

  get displayName() {
    return this.pokemon?.name ? this.pokemon.name[0].toUpperCase() + this.pokemon.name.slice(1) : '';
  }
}