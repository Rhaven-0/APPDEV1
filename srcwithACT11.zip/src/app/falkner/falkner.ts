import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { gymLeaderService } from '../gym-leader';

@Component({
  selector: 'app-falkner',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './falkner.html',
  styleUrl: './falkner.css'
})
export class Falkner {
  leader: any;
  pokemons: any[] = [];
  gymBadge = '';

  constructor(private gymLeaderService: gymLeaderService) {}

  ngOnInit() {
    this.leader = this.gymLeaderService.getLeaderByName('Falkner');
    if (this.leader) {
      this.pokemons = this.leader.pokemons;
      this.gymBadge = this.leader.gymBadge;
    }
  }
}