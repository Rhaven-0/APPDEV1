import { Component } from '@angular/core';
import {MatTableModule} from '@angular/material/table';
import { PokeballsService } from '../pokeballs-service';

@Component({
selector: 'app-pokeballs',
imports: [MatTableModule],
templateUrl: './pokeballs.html',
styleUrl: './pokeballs.css'
})
export class Pokeballs {
dataSource: { name: string; color: string; image: string }[] = [];
//Inject the service in to the component for vegetables
constructor(private pokeballService: PokeballsService) {}

//on the initialization of the component
//load the data
ngOnInit(): void {
    console.log('Pokeballs ngOnInit called');
    this.dataSource = this.pokeballService.getPokeballs();
  }
displayedColumns: string[] = ['image','name', 'color'];
}
