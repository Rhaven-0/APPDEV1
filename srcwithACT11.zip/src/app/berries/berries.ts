import { Component } from '@angular/core';
import {MatTableModule} from '@angular/material/table';
import { BerriesService } from '../berries-service';
@Component({
selector: 'app-berries',
imports: [MatTableModule],
templateUrl: './berries.html',
styleUrl: './berries.css'
})
export class Berries {
dataSource: { name: string; color: string; image: string; effects: string }[] = [];
//Inject the service in to the component for vegetables
constructor(private pokeballService: BerriesService) {}

//on the initialization of the component
//load the data
ngOnInit(): void {
    console.log('Berries ngOnInit called');
    this.dataSource = this.pokeballService.getBerries();
  }
displayedColumns: string[] = ['image', 'name', 'color', 'effects'];
}
