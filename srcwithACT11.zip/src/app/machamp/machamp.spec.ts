import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Machamp } from './machamp';

describe('Machamp', () => {
  let component: Machamp;
  let fixture: ComponentFixture<Machamp>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Machamp]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Machamp);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
