import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Sudowoodo } from './sudowoodo';

describe('Sudowoodo', () => {
  let component: Sudowoodo;
  let fixture: ComponentFixture<Sudowoodo>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Sudowoodo]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Sudowoodo);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
