import { Component } from '@angular/core';
import { Sudowoodo } from '../sudowoodo/sudowoodo';
import { Snorlax } from '../snorlax/snorlax';
import { Magikarp } from '../magikarp/magikarp';
import { Tyranitar } from '../tyranitar/tyranitar';
import { Mewtwo } from '../mewtwo/mewtwo';
import { Machamp } from '../machamp/machamp';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-my-favorite-pokemons',
  standalone: true,
  imports: [Sudowoodo, Snorlax,Magikarp, Tyranitar, Mewtwo, Machamp, MatFormFieldModule, MatSelectModule, ReactiveFormsModule, CommonModule],
  templateUrl: './my-favorite-pokemons.html',
  styleUrl: './my-favorite-pokemons.css'
})
export class MyFavoritePokemons {
  favoriteList = [
    { name: 'Sudowoodo', component: Sudowoodo },
    { name: 'Snorlax', component: Snorlax },
    { name: 'Magikarp', component: Magikarp },
    { name: 'Tyranitar', component: Tyranitar },
    { name: 'Mewtwo', component: Mewtwo },
    { name: 'Machamp', component: Machamp }
  ];

  selectedName = this.favoriteList[0].name;
}

