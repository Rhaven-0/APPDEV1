import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyFavoritePokemons } from './my-favorite-pokemons';

describe('MyFavoritePokemons', () => {
  let component: MyFavoritePokemons;
  let fixture: ComponentFixture<MyFavoritePokemons>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MyFavoritePokemons]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MyFavoritePokemons);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
