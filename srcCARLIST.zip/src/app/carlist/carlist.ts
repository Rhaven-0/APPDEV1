import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { forkJoin, of } from 'rxjs';
import { map } from 'rxjs/operators';


interface CarModel {
  Model_Name: string;
  imageUrl?: string;
}

@Component({
  selector: 'app-carlist',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './carlist.html',
  styleUrls: ['./carlist.css']
})
export class carlist implements OnInit {
  carMakers: any[] = [];  
  carModels: CarModel[] = [];  
  selectedMaker: string = '';
  selectedMakerName: string = '';
  isLoadingModels: boolean = false;
  
  private pexelsApiKey = 'LDkxcwQcaRA6HaShju9a2NEScXgpgHiapLRwfmkbnczSw91KBOwJSeeU';

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.loadCarMakers();
  }

loadCarMakers() {
  const popularMakers = [
    'TOYOTA', 'HONDA', 'FORD', 'CHEVROLET', 'NISSAN', 
    'BMW', 'MERCEDES-BENZ', 'AUDI', 'VOLKSWAGEN', 'HYUNDAI',
    'KIA', 'MAZDA', 'SUBARU', 'JEEP', 'RAM', 'GMC',
    'LEXUS', 'TESLA', 'PORSCHE', 'VOLVO', 'LAND ROVER',
    'JAGUAR', 'MINI', 'ACURA', 'INFINITI', 'CADILLAC',
    'LINCOLN', 'BUICK', 'DODGE', 'CHRYSLER', 'MITSUBISHI',
    'GENESIS', 'ALFA ROMEO', 'FIAT', 'MASERATI', 'FERRARI',
    'LAMBORGHINI', 'BENTLEY', 'ROLLS-ROYCE', 'ASTON MARTIN', 'MCLAREN'
  ];

  this.http
    .get<any>('https://vpic.nhtsa.dot.gov/api/vehicles/getallmanufacturers?format=json')
    .subscribe((data) => {
      this.carMakers = data.Results
        .filter((m: any) => {
          if (!m.Mfr_Name || !m.Mfr_ID) return false;
          const makerUpper = m.Mfr_Name.toUpperCase();
          return popularMakers.some(popular => makerUpper.includes(popular));
        })
        .map((m: any) => ({ id: m.Mfr_ID, name: m.Mfr_Name }))
        .sort((a: any, b: any) => a.name.localeCompare(b.name)); 
      
      console.log('Filtered makers:', this.carMakers.length);
    });
}

onMakerChange() {
  if (!this.selectedMaker) return;
  
  this.isLoadingModels = true;
  this.carModels = [];
  
  const maker = this.carMakers.find(m => m.id === this.selectedMaker);
  this.selectedMakerName = maker?.name || '';
  
  this.http
    .get<any>(`https://vpic.nhtsa.dot.gov/api/vehicles/getmodelsformakeid/${this.selectedMaker}?format=json`)
    .subscribe((data) => {
      const models = data.Results.slice(0, 12);
      
      if (models.length === 0) {
        this.isLoadingModels = false;
        return;
      }
      
      const imageRequests = models.map((model: any) => 
        this.fetchCarImage(this.selectedMakerName, model.Model_Name)
      );
      
      forkJoin<string[]>(imageRequests).subscribe((images: string[]) => {
        this.carModels = models.map((model: any, index: number) => ({
          Model_Name: model.Model_Name,
          imageUrl: images[index]
        }));
        this.isLoadingModels = false;
      });
    });
}

fetchCarImage(maker: string, model: string) {
  const colors = ['4A90E2', 'E74C3C', '2ECC71', 'F39C12', '9B59B6', '1ABC9C'];
  const colorIndex = maker.length % colors.length;
  const color = colors[colorIndex];
  
  return of(`https://placehold.co/400x300/${color}/FFFFFF?text=${encodeURIComponent(model)}`);
}
}
