import { Injectable } from '@angular/core';

export interface CarModel {
  Model_Name: string;
  imageUrl: string;
}

export interface CarMaker {
  id: string;
  name: string;
}

@Injectable({
  providedIn: 'root'
})
export class CarsService {
  
  private carData: { [key: string]: CarModel[] } = {
    'TOYOTA': [
      { Model_Name: 'Camry', imageUrl: 'camry.png' },
      { Model_Name: 'Supra', imageUrl: 'Supra.png' },
      { Model_Name: 'Fortuner', imageUrl: 'fortuner.png' }
    ],
    'HONDA': [
      { Model_Name: 'Civic Type R', imageUrl: 'civictyper.png' },
      { Model_Name: 'City', imageUrl: 'city.jpg' },
      { Model_Name: 'Brio', imageUrl: 'brio.png' }
    ],
    'FORD': [
      { Model_Name: 'Raptor', imageUrl: 'raptor.png' },
      { Model_Name: 'Mustang', imageUrl: 'mustang.png' },
      { Model_Name: 'Territory', imageUrl: 'territory.png' }
    ],
    'TESLA': [
      { Model_Name: 'Cybertruck', imageUrl: 'cybertruck.png' },
      { Model_Name: 'Model S', imageUrl: 'models.png' },
      { Model_Name: 'Model Y', imageUrl: 'modely.png' }
    ],
    'BMW': [
      { Model_Name: 'M2 Coupe', imageUrl: 'm2coupe.png' },
      { Model_Name: 'Z4 Roadster', imageUrl: 'z4roadster.png' },
      { Model_Name: 'i7', imageUrl: 'i7.png' }
    ],
    'MERCEDES-BENZ': [
      { Model_Name: 'G-Class', imageUrl: 'g-class.png' },
      { Model_Name: 'Maybach S-Class', imageUrl: 'maybachs-class.png' },
      { Model_Name: 'S-Class', imageUrl: 's-class.png' }
    ],
    'CHEVROLET': [
      { Model_Name: 'Corvette', imageUrl: 'corvette.png' },
      { Model_Name: 'Tahoe', imageUrl: 'tahoe.png' },
      { Model_Name: 'Trailblazer', imageUrl: 'trailblazer.png' }
    ],
    'NISSAN': [
      { Model_Name: 'Terra', imageUrl: 'terra.png' },
      { Model_Name: 'Leaf', imageUrl: 'leaf.png' },
      { Model_Name: 'GT-R', imageUrl: 'gtr.png' }
    ],
    'AUDI': [
      { Model_Name: 'R8', imageUrl: 'r8.png' },
      { Model_Name: 'Q8', imageUrl: 'q8.png' },
      { Model_Name: 'E-Tron GT', imageUrl: 'etrongt.png' }
    ],
    'PORSCHE': [
      { Model_Name: '911 Turbo S', imageUrl: '911turbos.png' },
      { Model_Name: 'Cayenne', imageUrl: 'cayenne.png' },
      { Model_Name: 'Macan', imageUrl: 'macan.png' }
    ],
    'Mitsubishi': [
      { Model_Name: 'Montero Sport', imageUrl: 'monterosport.png' },
      { Model_Name: 'Triton', imageUrl: 'triton.png' },
      { Model_Name: 'Xpander', imageUrl: 'xpander.png' }
    ],
    'Lamborghini': [
      { Model_Name: 'Revuelto', imageUrl: 'revuelto.png' },
      { Model_Name: 'Huracan', imageUrl: 'huracan.png' },
      { Model_Name: 'Urus', imageUrl: 'urus.png' }
    ],
    'Subaru': [
      { Model_Name: 'BRZ', imageUrl: 'brz.png' },
      { Model_Name: 'WRX STI', imageUrl: 'wrxsti.png' },
      { Model_Name: 'OUTBACK', imageUrl: 'outback.png' }
    ],
    'Ferrari': [
      { Model_Name: 'SF90', imageUrl: 'sf90.png' },
      { Model_Name: 'F12', imageUrl: 'f12.png' },
      { Model_Name: 'SP3', imageUrl: 'sp3.png' }
    ],
    'Rolls Royce': [
      { Model_Name: 'Cullinan', imageUrl: 'cullinan.png' },
      { Model_Name: 'Phantom', imageUrl: 'phantom.png' },
      { Model_Name: 'Spectre', imageUrl: 'spectre.png' }
    ]
  };

  constructor() { }

  getCarMakers(): CarMaker[] {
    return Object.keys(this.carData)
      .map(name => ({ id: name, name: name }))
      .sort((a, b) => a.name.localeCompare(b.name));
  }

  getModelsForMaker(makerId: string): CarModel[] {
    return this.carData[makerId] || [];
  }

  getAllCarData(): { [key: string]: CarModel[] } {
    return this.carData;
  }

  searchModels(query: string): Array<{maker: string, model: CarModel}> {
    if (!query || query.trim() === '') {
      return [];
    }
    
    const results: Array<{maker: string, model: CarModel}> = [];
    const searchTerm = query.toLowerCase().trim();
    
    Object.keys(this.carData).forEach(makerName => {
      this.carData[makerName].forEach(model => {
        if (model.Model_Name.toLowerCase().includes(searchTerm)) {
          results.push({
            maker: makerName,
            model: model
          });
        }
      });
    });
    
    return results;
  }
}


