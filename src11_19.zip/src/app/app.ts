import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { carlist } from './carlist/carlist';
import { HttpClientModule, HttpClientJsonpModule } from '@angular/common/http';
import { CarSearch } from './car-search/car-search';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    RouterOutlet,
    carlist,
    HttpClientModule,        
    HttpClientJsonpModule,
    CarSearch    
  ],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('carsite');
}
