import { Component } from '@angular/core';

@Component({
  selector: 'app-product-overview',
  standalone: false,
  templateUrl: './product-overview.component.html',
  styleUrl: './product-overview.component.css'
})
export class ProductOverviewComponent {
  leader = "Falkner";
  type = "Type: Flying";
  gymBadge = "Gym Badge: Zephyr Badge";
  pokemons = "Pokemons: Pidgey, Pidgeotto";
}

