import { Component } from '@angular/core';

@Component({
  selector: 'app-chuck',
  standalone: false,
  templateUrl: './chuck.component.html',
  styleUrl: './chuck.component.css'
})
export class ChuckComponent {
  leader = "Chuck";
  type = "Type: Fighting";
  gymBadge = "Gym Badge: Storm Badge";
  pokemons = "Pokemons: Primeape, Poliwrath";
}
