import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { InstructionsComponent } from './instructions/instructions.component';
import { KeyFeaturesComponent } from './key-features/key-features.component';
import { ProductOverviewComponent } from './product-overview/product-overview.component';
import { ProductSpecificationsComponent } from './product-specifications/product-specifications.component';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { ChuckComponent } from './chuck/chuck.component';
import { JasmineComponent } from './jasmine/jasmine.component';
import { PryceComponent } from './pryce/pryce.component';
import { ClairComponent } from './clair/clair.component';


@NgModule({
  declarations: [
    AppComponent,
    InstructionsComponent,
    KeyFeaturesComponent,
    ProductOverviewComponent,
    ProductSpecificationsComponent,
    SidebarComponent,
    LandingPageComponent,
    ChuckComponent,
    JasmineComponent,
    PryceComponent,
    ClairComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
