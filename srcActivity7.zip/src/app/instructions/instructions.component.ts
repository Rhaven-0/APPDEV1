import { Component } from '@angular/core';
import { KeyValuePipe } from '@angular/common';

@Component({
  selector: 'app-instructions',
  standalone: false,
  templateUrl: './instructions.component.html',
  styleUrl: './instructions.component.css'
})
export class InstructionsComponent {
  leader = "Morty";
  type = "Type: Ghost";
  gymBadge = "Gym Badge: Fog Badge";
  pokemons = "Pokemons: Gastly, Haunter, Haunter, Gengar";
}

