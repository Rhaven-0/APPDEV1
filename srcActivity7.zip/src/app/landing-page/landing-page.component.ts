import { Component } from '@angular/core';

@Component({
  selector: 'app-landing-page',
  standalone: false,
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.css']
})
export class LandingPageComponent {
  lore = "Pokedex of Johto Gym Leaders Welcome to the Johto Region! Known for its rich traditions and deep connection to history." 
  gymLeaders = "Johto is home to eight Gym Leaders who test trainers on their journey to greatness Each Gym Leader specializes in a unique type of Pokemon and awards a badge to trainers who can prove their strength."
}
