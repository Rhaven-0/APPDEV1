import { Component } from '@angular/core';

@Component({
  selector: 'app-pryce',
  standalone: false,
  templateUrl: './pryce.component.html',
  styleUrl: './pryce.component.css'
})
export class PryceComponent {
  leader = "Pryce";
  type = "Type: Ice";
  gymBadge = "Gym Badge: Glacier Badge";
  pokemons = "Pokemons: Seel, Dewgong, Piloswine";
}
