import { Component } from '@angular/core';

@Component({
  selector: 'app-product-specifications',
  standalone: false,
  templateUrl: './product-specifications.component.html',
  styleUrl: './product-specifications.component.css'
})
export class ProductSpecificationsComponent {
  leader = "Bugsy";
  type = "Type: Bug";
  gymBadge = "Gym Badge: Hive Badge";
  pokemons = "Pokemons: Metapod, Kakuna, Scyther";
}
