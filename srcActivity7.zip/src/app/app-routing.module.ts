import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProductOverviewComponent } from './product-overview/product-overview.component';
import { ProductSpecificationsComponent } from './product-specifications/product-specifications.component';
import { KeyFeaturesComponent } from './key-features/key-features.component';
import { InstructionsComponent } from './instructions/instructions.component';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { ChuckComponent } from './chuck/chuck.component';
import { JasmineComponent } from './jasmine/jasmine.component';
import { PryceComponent } from './pryce/pryce.component';
import { ClairComponent } from './clair/clair.component';

const routes: Routes = [
  {
    path: 'overview', component: ProductOverviewComponent,
  },
  {
    path: 'specifications', component: ProductSpecificationsComponent,
  },
  {
    path: 'key-features', component: KeyFeaturesComponent,
  },
  {
    path: 'instructions', component: InstructionsComponent,
  },
  {
    path: 'chuck', component: ChuckComponent,
  },
  {
    path: 'jasmine', component: JasmineComponent,
  },
  {
    path: 'pryce', component: PryceComponent,
  },
  {
    path: 'clair', component: ClairComponent,
  },
  {
    path: 'landingPage', component: LandingPageComponent,
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
