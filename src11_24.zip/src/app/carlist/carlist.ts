import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { CarsService, CarModel, CarMaker } from '../cars-service';

@Component({
  selector: 'app-carlist',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './carlist.html',
  styleUrls: ['./carlist.css']
})
export class carlist implements OnInit {
  carMakers: CarMaker[] = [];
  carModels: CarModel[] = [];
  selectedMaker: string = '';
  selectedCar: CarModel | null = null;
  showSpecs: boolean = false;

  constructor(private carsService: CarsService) {}

  ngOnInit(): void {
    this.loadCarMakers();
  }

  loadCarMakers() {
    this.carMakers = this.carsService.getCarMakers();
    console.log('Loaded makers:', this.carMakers.length);
  }

  onMakerChange() {
    if (!this.selectedMaker) {
      this.carModels = [];
      return;
    }
    this.carModels = this.carsService.getModelsForMaker(this.selectedMaker);
    this.selectedCar = null;
    this.showSpecs = false;
    console.log('Showing models for', this.selectedMaker, ':', this.carModels);
  }

  onCarClick(car: CarModel) {
    this.selectedCar = car;
    this.showSpecs = true;
    console.log('Selected car:', car);
  }

  closeSpecs() {
    this.showSpecs = false;
    this.selectedCar = null;
  }
}