import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CarsService, CarModel } from '../cars-service';

interface SearchResult {
  maker: string;
  model: CarModel;
}

@Component({
  selector: 'app-car-search',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './car-search.html',
  styleUrls: ['./car-search.css']
})
export class CarSearch {
  isSearchOpen: boolean = false;
  searchQuery: string = '';
  searchResults: SearchResult[] = [];
  
  constructor(private carsService: CarsService) {}
  
  toggleSearch() {
    this.isSearchOpen = !this.isSearchOpen;
    if (!this.isSearchOpen) {
      this.searchQuery = '';
      this.searchResults = [];
    }
  }
  
  onSearch() {
    if (this.searchQuery.trim() === '') {
      this.searchResults = [];
      return;
    }
    
    this.searchResults = this.carsService.searchModels(this.searchQuery);
  }
  
  clearSearch() {
    this.searchQuery = '';
    this.searchResults = [];
  }
}