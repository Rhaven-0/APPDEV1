import { TestBed } from '@angular/core/testing';

import { FirePokemons } from './fire-pokemons';

describe('FirePokemons', () => {
  let service: FirePokemons;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FirePokemons);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
