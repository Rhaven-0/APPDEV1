import { Injectable } from '@angular/core';
import { PokemonStats } from './water-pokemons';
@Injectable({
  providedIn: 'root'
})
export class FirePokemonsService {
  private readonly firePokemons: PokemonStats[] = [
    { 
      name: 'Cyndaquil',
      hp: 39, 
      attack: 52, 
      defense: 43, 
      specialattack: 60, 
      specialdefense: 50, 
      speed: 65, 
      type: 'Fire',
      image: 'Cyndaquil.png'
    },
    {
      name: 'Quilava',
      hp: 58, 
      attack: 64, 
      defense: 58, 
      specialattack: 80, 
      specialdefense: 65, 
      speed: 80, 
      type: 'Fire',
      image: 'Quilava.png'
    },
    {
      name: 'Typhlosion',
      hp: 78, 
      attack: 84, 
      defense: 78, 
      specialattack: 109, 
      specialdefense: 85, 
      speed: 100, 
      type: 'Fire',
      image: 'Typhlosion.png'
    }
  ];
  constructor() {}

  getFirePokemons(): PokemonStats[] {
    return [...this.firePokemons];
  }

  getFirePokemonByName(name: string): PokemonStats | undefined {
    return this.firePokemons.find(
      p => p.name.toLowerCase() === name.toLowerCase()
    );
  }
}
