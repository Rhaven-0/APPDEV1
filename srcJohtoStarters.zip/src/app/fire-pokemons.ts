import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FirePokemonsService {
  private readonly firePokemons: Pokemon[] = [
    { 
      name: 'Cyndaquil',
      hp: 39, 
      attack: 52, 
      defense: 43, 
      specialattack: 60, 
      specialdefense: 50, 
      speed: 65, 
      type: 'Fire'
    },
    {
      name: 'Quilava',
      hp: 58, 
      attack: 64, 
      defense: 58, 
      specialattack: 80, 
      specialdefense: 65, 
      speed: 80, 
      type: 'Fire'
    },
    {
      name: 'Typhlosion',
      hp: 78, 
      attack: 84, 
      defense: 78, 
      specialattack: 109, 
      specialdefense: 85, 
      speed: 100, 
      type: 'Fire'
    }
  ];
}
