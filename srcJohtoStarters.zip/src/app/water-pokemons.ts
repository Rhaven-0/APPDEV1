import { Injectable } from '@angular/core';

export interface PokemonStats {
  name: string;
  hp: number;
  attack: number;
  defense: number;
  specialattack: number;
  specialdefense: number;
  speed: number;
  type: string;
  image: string;
}

@Injectable({
  providedIn: 'root'
})
export class WaterPokemonsService {

  private readonly waterPokemons: PokemonStats[] = [
    { 
      name: 'Totodile',
      hp: 50, 
      attack: 65, 
      defense: 64, 
      specialattack: 44, 
      specialdefense: 48, 
      speed: 43, 
      type: 'Water',
      image: 'Totodile.png'
    },
    {
      name: 'Croconaw',
      hp: 65, 
      attack: 80, 
      defense: 80, 
      specialattack: 59, 
      specialdefense: 63, 
      speed: 58, 
      type: 'Water',
      image: 'Croconaw.png'
    },
    {
      name: 'Feraligatr',
      hp: 85, 
      attack: 105, 
      defense: 100, 
      specialattack: 79, 
      specialdefense: 83, 
      speed: 78, 
      type: 'Water',
      image: 'Feraligatr.png'
    }
  ];

  constructor() {}

  getWaterPokemons(): PokemonStats[] {
    return [...this.waterPokemons];
  }

  getWaterPokemonByName(name: string): PokemonStats | undefined {
    return this.waterPokemons.find(
      p => p.name.toLowerCase() === name.toLowerCase()
    );
  }
}
