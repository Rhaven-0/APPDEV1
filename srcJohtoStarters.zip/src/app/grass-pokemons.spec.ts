import { TestBed } from '@angular/core/testing';

import { GrassPokemons } from './grass-pokemons';

describe('GrassPokemons', () => {
  let service: GrassPokemons;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GrassPokemons);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
