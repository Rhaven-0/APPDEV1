import { Component } from '@angular/core';
import { PokemonStats } from '../water-pokemons';
import { FirePokemonsService } from '../fire-pokemons';
@Component({
  selector: 'app-fire-pokemon',
  imports: [],
  templateUrl: './fire-pokemon.html',
  styleUrl: './fire-pokemon.css'
})
export class FirePokemon {
    pokemons: PokemonStats[] = [];
    currentIndex = 0;
    currentPokemon!: PokemonStats;
  
    constructor(private waterPokemonService: FirePokemonsService) {}
  
    ngOnInit(): void {
      this.pokemons = this.waterPokemonService.getFirePokemons();
      this.currentPokemon = this.pokemons[this.currentIndex];
    }
  
    nextEvolution(): void {
      if (this.currentIndex < this.pokemons.length - 1) {
        this.currentIndex++;
        this.currentPokemon = this.pokemons[this.currentIndex];
      }
    }
  
    prevEvolution(): void {
      if (this.currentIndex > 0) {
        this.currentIndex--;
        this.currentPokemon = this.pokemons[this.currentIndex];
      }
    }
  
    canEvolve(): boolean {
      return this.currentIndex < this.pokemons.length - 1;
    }
  
    canRevert(): boolean {
      return this.currentIndex > 0;
    }
  }
