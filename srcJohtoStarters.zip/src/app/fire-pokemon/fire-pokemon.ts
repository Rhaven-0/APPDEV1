import { Component } from '@angular/core';

@Component({
  selector: 'app-fire-pokemon',
  imports: [],
  templateUrl: './fire-pokemon.html',
  styleUrl: './fire-pokemon.css'
})
export class FirePokemon {
}
