import { Component } from '@angular/core';
import { WaterPokemonsService, PokemonStats } from '../water-pokemons';

@Component({
  selector: 'app-water-pokemon',
  standalone: true,
  templateUrl: './water-pokemon.html',
  styleUrls: ['./water-pokemon.css']
})
export class WaterPokemon {
  pokemons: PokemonStats[] = [];
  currentIndex = 0;
  currentPokemon!: PokemonStats;

  constructor(private waterPokemonService: WaterPokemonsService) {}

  ngOnInit(): void {
    this.pokemons = this.waterPokemonService.getWaterPokemons();
    this.currentPokemon = this.pokemons[this.currentIndex];
  }

  nextEvolution(): void {
    if (this.currentIndex < this.pokemons.length - 1) {
      this.currentIndex++;
      this.currentPokemon = this.pokemons[this.currentIndex];
    }
  }

  prevEvolution(): void {
    if (this.currentIndex > 0) {
      this.currentIndex--;
      this.currentPokemon = this.pokemons[this.currentIndex];
    }
  }

  canEvolve(): boolean {
    return this.currentIndex < this.pokemons.length - 1;
  }

  canRevert(): boolean {
    return this.currentIndex > 0;
  }
}

