import { Component } from '@angular/core';
import { WaterPokemonsService, Pokemon } from '../water-pokemons';

@Component({
  selector: 'app-water-pokemon',
  standalone: true,
  templateUrl: './water-pokemon.html',
  styleUrls: ['./water-pokemon.css']
})
export class WaterPokemon {
  pokemons: Pokemon[] = [];
  currentIndex = 0;
  currentPokemon!: Pokemon;

  constructor(private waterPokemonService: WaterPokemonsService) {}
  
}
