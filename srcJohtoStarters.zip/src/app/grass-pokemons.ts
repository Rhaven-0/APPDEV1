import { Injectable } from '@angular/core';
import { PokemonStats } from './water-pokemons';

@Injectable({
  providedIn: 'root'
})

export class GrassPokemonsService {
  private readonly grassPokemons: PokemonStats[] = [
    { 
      name: 'Chikorita',
      hp: 45, 
      attack: 49, 
      defense: 65, 
      specialattack: 49, 
      specialdefense: 65, 
      speed: 45, 
      type: 'Grass',
      image: 'Chikorita.png'
    },
    {
      name: 'Bayleef',
      hp: 60, 
      attack: 62, 
      defense: 80, 
      specialattack: 63, 
      specialdefense: 80, 
      speed: 60, 
      type: 'Grass',
      image: 'Bayleef.png'
    },
    {
      name: 'Meganium',
      hp: 80, 
      attack: 82, 
      defense: 100, 
      specialattack: 83, 
      specialdefense: 100, 
      speed: 80, 
      type: 'Grass',
      image: 'Meganium.png'
    }
  ];
  constructor() {}

  getGrassPokemons(): PokemonStats[] {
    return [...this.grassPokemons];
  }

  getGrassPokemonByName(name: string): PokemonStats | undefined {
    return this.grassPokemons.find(
      p => p.name.toLowerCase() === name.toLowerCase()
    );
  }
}
