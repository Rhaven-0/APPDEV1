import { Component } from '@angular/core';

@Component({
  selector: 'app-grass-pokemon',
  imports: [],
  templateUrl: './grass-pokemon.html',
  styleUrl: './grass-pokemon.css'
})
export class GrassPokemon {

}
