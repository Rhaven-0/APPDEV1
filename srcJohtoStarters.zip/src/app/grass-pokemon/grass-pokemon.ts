import { Component } from '@angular/core';
import { GrassPokemonsService } from '../grass-pokemons';
import { PokemonStats } from '../water-pokemons';
@Component({
  selector: 'app-grass-pokemon',
  imports: [],
  templateUrl: './grass-pokemon.html',
  styleUrl: './grass-pokemon.css'
})
export class GrassPokemon {
  pokemons: PokemonStats[] = [];
  currentIndex = 0;
  currentPokemon!: PokemonStats;

  constructor(private GrassPokemonsService: GrassPokemonsService) {}

  ngOnInit(): void {
    this.pokemons = this.GrassPokemonsService.getGrassPokemons();
    this.currentPokemon = this.pokemons[this.currentIndex];
  }

  nextEvolution(): void {
    if (this.currentIndex < this.pokemons.length - 1) {
      this.currentIndex++;
      this.currentPokemon = this.pokemons[this.currentIndex];
    }
  }

  prevEvolution(): void {
    if (this.currentIndex > 0) {
      this.currentIndex--;
      this.currentPokemon = this.pokemons[this.currentIndex];
    }
  }

  canEvolve(): boolean {
    return this.currentIndex < this.pokemons.length - 1;
  }

  canRevert(): boolean {
    return this.currentIndex > 0;
  }
}
