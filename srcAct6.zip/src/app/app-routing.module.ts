import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MeditationsComponent } from './meditations/meditations.component';
import { TaotechingComponent } from './taoteching/taoteching.component';

const routes: Routes = [
  { path: 'meditations', component: MeditationsComponent },
  { path: 'taoteching', component: TaotechingComponent },
  { path: '', redirectTo: '/meditations', pathMatch: 'full' } 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
