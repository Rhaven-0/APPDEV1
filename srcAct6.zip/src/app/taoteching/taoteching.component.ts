import { Component } from '@angular/core';

@Component({
  selector: 'app-taoteching',
  standalone: false,
  templateUrl: './taoteching.component.html',
  styleUrl: './taoteching.component.css'
})
export class TaotechingComponent {
  stoicPhilosophy = [
    {
      book: 'Quote 1',
      body: 'The tao that can be told is not the real Tao. The name that can be named is not the eternal Name'
    },
    {
      book: 'Quote 2',
      body: 'The unnamable is the eternally real. Naming is the origin of all particular things.'
    },
    {
      book: 'Quote 3',
      body: 'Free from desire, you realize the mystery. Caught in desire, you see only the manifestations.'
    },
    {
      book: 'Quote 4',
      body: 'Darkness within darkness. The gateway to all understanding.'
    },
    {
      book: 'Quote 5',
      body: 'If you overesteem great men, people become powerless. If you overvalue possessions, people begin to steal.'
    }
  ]

  currentIndex: number = 0;
  currentQuote = this.stoicPhilosophy[0];

  increment() {
    if (this.currentIndex < this.stoicPhilosophy.length - 1) {
      this.currentIndex++;
      this.currentQuote = this.stoicPhilosophy[this.currentIndex];
    }
    else if(this.currentIndex == this.stoicPhilosophy.length - 1){
      this.currentIndex = 0;
      this.currentQuote = this.stoicPhilosophy[this.currentIndex];
    }

  }

  decrement() {
    if (this.currentIndex > 0) {
      this.currentIndex--;
      this.currentQuote = this.stoicPhilosophy[this.currentIndex];
    }
    if(this.currentIndex == 0){
      this.currentIndex = this.stoicPhilosophy.length - 1;
      this.currentQuote = this.stoicPhilosophy[this.currentIndex];
    }
  }
}

