import { Component } from '@angular/core';
import { Pokemon } from '../water-pokemons';
import { FirePokemonsService } from '../fire-pokemons';
@Component({
  selector: 'app-fire-pokemon',
  imports: [],
  templateUrl: './fire-pokemon.html',
  styleUrl: './fire-pokemon.css'
})
export class FirePokemon {
  pokemons: Pokemon[] = [];
    currentIndex = 0;
    currentPokemon!: Pokemon;
  
    constructor(private waterPokemonService: FirePokemonsService) {}
  
    ngOnInit(): void {
      this.pokemons = this.waterPokemonService.getFirePokemons();
      this.currentPokemon = this.pokemons[this.currentIndex];
    }
  
    nextEvolution(): void {
      this.currentIndex = (this.currentIndex + 1) % this.pokemons.length;
      this.currentPokemon = this.pokemons[this.currentIndex];
    }
  
    prevEvolution(): void {
      this.currentIndex = (this.currentIndex - 1) % this.pokemons.length;
      this.currentPokemon = this.pokemons[this.currentIndex];
    }
}
