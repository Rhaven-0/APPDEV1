import { Injectable } from '@angular/core';
import { Pokemon } from './water-pokemons';
@Injectable({
  providedIn: 'root'
})
export class GrassPokemonsService {
  private readonly grassPokemons: Pokemon[] = [
    { 
      name: 'Chikorita',
      hp: 45, 
      attack: 49, 
      defense: 65, 
      specialattack: 49, 
      specialdefense: 65, 
      speed: 45, 
      type: 'Grass'
    },
    {
      name: 'Bayleef',
      hp: 60, 
      attack: 62, 
      defense: 80, 
      specialattack: 63, 
      specialdefense: 80, 
      speed: 60, 
      type: 'Grass'
    },
    {
      name: 'Meganium',
      hp: 80, 
      attack: 82, 
      defense: 100, 
      specialattack: 83, 
      specialdefense: 100, 
      speed: 80, 
      type: 'Grass'
    }
  ];
}
