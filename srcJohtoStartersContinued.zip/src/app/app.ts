import { Component, signal } from '@angular/core';
import { WaterPokemon } from './water-pokemon/water-pokemon';
import { FirePokemon } from './fire-pokemon/fire-pokemon';
import { GrassPokemon } from './grass-pokemon/grass-pokemon';

@Component({
  selector: 'app-root',
  imports: [WaterPokemon, FirePokemon, GrassPokemon],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('Johto-Starters');
}
