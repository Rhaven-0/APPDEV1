import { TestBed } from '@angular/core/testing';

import { WaterPokemons } from './water-pokemons';

describe('WaterPokemons', () => {
  let service: WaterPokemons;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(WaterPokemons);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
