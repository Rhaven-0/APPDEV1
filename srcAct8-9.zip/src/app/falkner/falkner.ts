import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-falkner',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './falkner.html',
  styleUrl: './falkner.css'
})
export class Falkner {
  leader = [
  { name: 'Falkner', 
    img: 'Falkner.png',
    specialty: 'Flying'
  }
];

  gymBadge = 'Zephyr Badge'
  pokemons = [
  { name: 'Pidgey', img: 'Pidgey.png' },
  { name: 'Pidgeotto', img: 'Pidgeotto.png' }
];

}
