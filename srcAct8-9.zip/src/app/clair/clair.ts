import { Component } from '@angular/core';

@Component({
  selector: 'app-clair',
  imports: [],
  templateUrl: './clair.html',
  styleUrl: './clair.css'
})
export class Clair {
leader = [
  { name: 'Clair', 
    img: 'Clair.png',
    specialty: 'Dragon'
  }
];
  gymBadge = 'Storm Badge'
  pokemons = [
  { name: 'Dragonair', img: 'Dragonair.png' },
  { name: 'Dragonair', img: 'Dragonair.png' },
  { name: 'Dragonair', img: 'Dragonair.png' },
  { name: 'Kingdra', img: 'Kingdra.png' },
];
}
