import { Component } from '@angular/core';

@Component({
  selector: 'app-pryce',
  imports: [],
  templateUrl: './pryce.html',
  styleUrl: './pryce.css'
})
export class Pryce {
leader = [
  { name: 'Pryce', 
    img: 'Pryce.png',
    specialty: 'Ice'
  }
];
  gymBadge = 'Storm Badge'
  pokemons = [
  { name: 'Seel', img: 'Seel.png' },
  { name: 'Dewgong', img: 'Dewgong.png' },
  { name: 'Piloswine', img: 'Piloswine.png' }
];
}
