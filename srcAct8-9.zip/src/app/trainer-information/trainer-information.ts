import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-trainer-registration',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './trainer-information.html',
  styleUrls: ['./trainer-information.css']
})
export class TrainerForm {
  formGroup: FormGroup;
  trainerList: any[] = [];

  constructor(private fb: FormBuilder) {
    this.formGroup = this.fb.group({
      name: [''],
      age: [''],
      address: [''],
      team: ['']
    });
  }

  onSubmit(): void {
    if (this.formGroup.valid) {
      this.trainerList.push(this.formGroup.value);
      this.formGroup.reset();
    }
  }
}
