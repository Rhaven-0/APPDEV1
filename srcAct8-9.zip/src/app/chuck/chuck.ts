import { Component } from '@angular/core';

@Component({
  selector: 'app-chuck',
  imports: [],
  templateUrl: './chuck.html',
  styleUrl: './chuck.css'
})
export class Chuck {
leader = [
  { name: 'Chuck', 
    img: 'Chuck.png',
    specialty: 'Fighting'
  }
];
  gymBadge = 'Storm Badge'
  pokemons = [
  { name: 'Primeape', img: 'Primeape.png' },
  { name: 'Poliwrath', img: 'Poliwrath.png' }
];
}
