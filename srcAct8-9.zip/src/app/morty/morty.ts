import { Component } from '@angular/core';

@Component({
  selector: 'app-morty',
  imports: [],
  standalone: true,
  templateUrl: './morty.html',
  styleUrl: './morty.css'
})
export class Morty {
  leader = [
  { name: 'Morty', 
    img: 'Morty.png',
    specialty: 'Ghost'
  }
];
  gymBadge = 'Fog Badge'
  pokemons = [
  { name: 'Gastly', img: 'Gastly.png' },
  { name: 'Haunter', img: 'Haunter.png' },
  { name: 'Haunter', img: 'Haunter.png' },
  { name: 'Gengar', img: 'Gengar.png' },
];
}
