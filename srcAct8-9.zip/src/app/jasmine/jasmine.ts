import { Component } from '@angular/core';

@Component({
  selector: 'app-jasmine',
  imports: [],
  templateUrl: './jasmine.html',
  styleUrl: './jasmine.css'
})
export class Jasmine {
leader = [
  { name: 'Jasmine', 
    img: 'Jasmine.png',
    specialty: 'Steel'
  }
];
  gymBadge = 'Mineral Badge'
  pokemons = [
  { name: 'Magnemite', img: 'Magnemite.png' },
  { name: 'Magnemite', img: 'Magnemite.png' },
  { name: 'Steelix', img: 'Steelix.png' }
];
}
