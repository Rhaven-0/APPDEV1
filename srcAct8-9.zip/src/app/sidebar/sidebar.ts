import { Component, inject } from '@angular/core';
import {RouterLink, RouterModule} from '@angular/router';
import {Router} from '@angular/router';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [RouterModule],
  templateUrl: './sidebar.html',
  styleUrls: ['./sidebar.css']
})
export class Sidebar {
  private router = inject(Router)

  navigateToHome(){
    this.router.navigate(['/'])
  }
}

