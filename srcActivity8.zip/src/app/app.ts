import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { PokemonListComponent } from './pokemon-list/pokemon-list';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, PokemonListComponent],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  title = 'legendary-pokemon';
}