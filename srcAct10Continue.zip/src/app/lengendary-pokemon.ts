import { Injectable, isStandalone } from '@angular/core';

@Injectable({
providedIn: 'root'//The service is available through out thea pplication
})
export class LegendaryPokemon {
constructor() {
}
getKantoLegendaries() {
  return [
    { name: 'Articuno', type: 'Ice/Flying', image: 'Articuno.png' },
    { name: 'Zapdos', type: 'Electric/Flying', image: 'Zapdos.png' },
    { name: 'Moltres', type: 'Fire/Flying', image: 'Moltres.png' },
    { name: 'Mewtwo', type: 'Psychic', image: 'Mewtwo.png' },
    { name: 'Mew', type: 'Psychic', image: 'Mew.png' }
  ];
}

getJohtoLegendaries() {
  return [
    { name: 'Raikou', type: 'Electric', image: 'Raikou.png' },
    { name: 'Entei', type: 'Fire', image: 'Entei.png' },
    { name: 'Suicune', type: 'Water', image: 'Suicune.png' },
    { name: 'Lugia', type: 'Psychic/Flying', image: 'Lugia.png' },
    { name: 'Ho-Oh', type: 'Fire/Flying', image: 'Ho-Oh.png' },
    { name: 'Celebi', type: 'Psychic/Grass', image: 'Celebi.png' }
  ];
}
}
