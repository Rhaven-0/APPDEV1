import { Component } from '@angular/core';

@Component({
  selector: 'app-whitney',
  imports: [],
  standalone: true,
  templateUrl: './whitney.html',
  styleUrl: './whitney.css'
})
export class Whitney {
  leader = [
  { name: 'Whitney', 
    img: 'Whitney.png',
    specialty: 'Normal'
  }
];

 
  gymBadge = 'Plain Badge'
  pokemons = [
  { name: 'Clefairy', img: 'Clefairy.png' },
  { name: 'Miltank', img: 'Miltank.png' }
];

}

