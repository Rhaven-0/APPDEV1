import { Component } from '@angular/core';
import {MatTableModule} from '@angular/material/table';
import { BerriesService } from '../berries-service';
@Component({
selector: 'app-berries',
imports: [MatTableModule],
templateUrl: './berries.html',
styleUrl: './berries.css'
})
export class Berries {
dataSource: {name: string; color: string}[] = [];
//Inject the service in to the component for fruits
constructor(private f: BerriesService){
}
//on the initialization of the component
//load the data
ngOnInit(): void {
console.log('ngOnInit called');
this.dataSource = this.f.getFruits();
}
displayedColumns: string[] = ['name', 'color']
}
