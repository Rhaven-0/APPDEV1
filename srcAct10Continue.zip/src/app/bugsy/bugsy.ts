import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-bugsy',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './bugsy.html',
  styleUrl: './bugsy.css'
})
export class Bugsy {
   leader = [
  { name: 'Bugsy', 
    img: 'Bugsy.png',
    specialty: 'Bugs'
  }
];
  gymBadge = 'Hive Badge'
  pokemons = [
  { name: 'Metapod', img: 'Metapod.png' },
  { name: 'Kakuna', img: 'Kakuna.png' },
  { name: 'Scyther', img: 'Scyther.png' }
];
}
