// src/app/preview/preview.ts

import { Component, Input, OnInit, OnChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CarConfiguration } from '../configuration/configuration';
import { CustomizerService } from '../customization-service';

@Component({
  selector: 'app-car-preview',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './preview.html', 
  styleUrl: './preview.css'        
})
export class CarPreviewComponent implements OnInit, OnChanges {
  @Input() config: CarConfiguration | null = null;
  
  angles = ['front', 'side', 'rear', 'interior'];
  currentAngle = 'side';
  currentImageUrl = '';

  constructor(private customizerService: CustomizerService) {}

  ngOnInit() {
    this.updateImageUrl();
  }

  ngOnChanges() {
    this.updateImageUrl();
  }

  changeAngle(angle: string) {
    this.currentAngle = angle;
    this.updateImageUrl();
  }

  updateImageUrl() {
    if (this.config) {
      this.currentImageUrl = this.customizerService.getCarImageUrl(this.config, this.currentAngle);
    }
  }

  onImageError(event: any) {
    event.target.src = '/cars/placeholder.jpg';
    console.warn('Image not found:', this.currentImageUrl);
  }
}