// app.routes.ts

import { Routes } from '@angular/router';
import { carlist } from './carlist/carlist';
import { Customization } from './customization/customization';

export const routes: Routes = [
  {
    path: '',
    component: carlist,
    pathMatch: 'full'
  },
  {
    path: 'cars/:maker/:model/customize',
    component: Customization
  },
  {
    path: '**',
    redirectTo: ''
  }
];